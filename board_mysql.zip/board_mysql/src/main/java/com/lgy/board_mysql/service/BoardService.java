package com.lgy.board_mysql.service;

import org.springframework.ui.Model;

public interface BoardService {
	public void excute(Model model);

}
